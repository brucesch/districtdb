<fieldset class="adminform">
			<ul class="adminformlist">
				<li>
					<div id="plugins"></div>
			<a href="#" class="addButton" id="addPlugin"><?php echo JText::_('COM_FABRIK_ADD'); ?></a>
				</li>
			</ul>
		</fieldset>