<?php echo JHtml::_('tabs.panel', JText::_('COM_FABRIK_JAVASCRIPT'), 'settings');
?>
<div id="javascriptActions"></div>
<a class="addButton" href="#" id="addJavascript"><?php echo JText::_('COM_FABRIK_ADD'); ?></a>
