<?php echo JHtml::_('tabs.panel',JText::_('COM_FABRIK_GROUP_LABAEL_PLUGINS_DETAILS'), 'list-plugins-panel');?>
<fieldset class="adminform">
	<div id="plugins"></div>
	<a href="#" id="addPlugin" class="addButton"><?php echo JText::_('COM_FABRIK_ADD'); ?></a>

</fieldset>