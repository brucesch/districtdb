DROP TABLE IF EXISTS  `#__fabrik_log`;
DROP TABLE IF EXISTS   `#__fabrik_jsactions`;
DROP TABLE IF EXISTS  `#__fabrik_joins`;
DROP TABLE IF EXISTS  `#__fabrik_connections`;
DROP TABLE IF EXISTS  `#__fabrik_lists`;
DROP TABLE IF EXISTS  `#__fabrik_validations`;
DROP TABLE IF EXISTS  `#__fabrik_forms`;
DROP TABLE IF EXISTS  `#__fabrik_elements`;
DROP TABLE IF EXISTS  `#__fabrik_formgroup`;
DROP TABLE IF EXISTS  `#__fabrik_groups`;
DROP TABLE IF EXISTS  `#__fabrik_packages`;
DROP TABLE IF EXISTS  `#__fabrik_visualizations`;
DROP TABLE IF EXISTS  `#__fabrik_cron`;
DROP TABLE IF EXISTS `#__fabrik_form_sessions`;

