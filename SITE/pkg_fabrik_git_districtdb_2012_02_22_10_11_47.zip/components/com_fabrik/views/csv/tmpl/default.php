<?php

/**
* @package Joomla
* @subpackage Fabrik
* @copyright Copyright (C) 2005 Rob Clayburn. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
*/

// no direct access
defined('_JEXEC') or die('Restricted access');
?>
<form name="listform_<?php echo $this->id?>" id="listform_<?php echo $this->id?>">
</form>
<!-- secret hihi hello linh! (H) -->