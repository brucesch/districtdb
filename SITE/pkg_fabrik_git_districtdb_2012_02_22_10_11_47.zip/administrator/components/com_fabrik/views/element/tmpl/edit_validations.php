<?php echo JHtml::_('tabs.panel', JText::_('COM_FABRIK_VALIDATIONS'), 'settings');
?>
<div id="plugins">
</div>
<a href="#" class="addButton" id="addPlugin"><?php echo JText::_('COM_FABRIK_ADD'); ?></a>
